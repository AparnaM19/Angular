import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from './User';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  user: User;
  title = 'my app';
  paraFlag = true;
  tableFlag = false;
  dateText = 'hover on the button to see current date';
  items = ['one', 'two', 'three', 'four'];
  textStyle;

  books: any[];

  constructor() {
    this.user = new User();
    this.books = [
      {
        id: "1", name: "java", author: "John", price: "500"
      },
      {
        id: "2", name: "c#", author: "Ray", price: "430"
      },
      {
        id: "3", name: "angular", author: "Mary", price: "960"
      }
    ];
  }8

  toggleDiv() {
    this.paraFlag = !this.paraFlag;
  }

  onMouseOver() {
    this.textStyle = "text-primary";
    this.dateText = new Date().toString();
  }

  onMouseOut() {
    this.textStyle = "";
    this.dateText = 'hover on the button to see current date';
  }

  toggleTable(){
    this.tableFlag =  !this.tableFlag;
  }


}
