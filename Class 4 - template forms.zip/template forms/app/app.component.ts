import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from './User';
import { Book } from './Book';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  user: User;
  loginStatus: number;
  
  constructor() {
    this.user = new User();
    this.loginStatus = -1;
  }

  signUp(userForm) {
    console.log(userForm);
    if (userForm.form.value.email == "admin@gmail.com" && userForm.form.value.password == "admin123")
      this.loginStatus = 1;
    else
      this.loginStatus = 0;
  }
}
